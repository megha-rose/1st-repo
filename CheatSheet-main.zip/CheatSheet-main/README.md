# CheatSheet for all programming languages

## Table of Content

- C Programming
- C# Programming
- C++ Programming
- Java Programming: (https://github.com/Singhavi279/CheatSheet/blob/main/Java.md)
- HTML
- CSS
- JavaScript
- SQL Queries:  (https://github.com/Singhavi279/CheatSheet/blob/main/SQL.md)
- R Programming: (https://github.com/Singhavi279/CheatSheet/blob/main/r-cheatsheet.md)
